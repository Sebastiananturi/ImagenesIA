# nevera2 > 2024-03-18 9:48am
https://universe.roboflow.com/sebastian-anturi-3bvx0/nevera2

Provided by a Roboflow user
License: CC BY 4.0

