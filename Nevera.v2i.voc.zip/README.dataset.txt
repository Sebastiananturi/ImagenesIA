# Nevera > 2024-03-14 12:46pm
https://universe.roboflow.com/sebastian-anturi-3bvx0/nevera-hanuy

Provided by a Roboflow user
License: CC BY 4.0

